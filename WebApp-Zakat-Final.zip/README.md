# WebApp-Zakat-Ryuu

Web-App-Zakat tugas kelompok UTS Semester 4. 
Anggota Kelompok:
  - Ryu Kevin Benardi (2222015196)
  - Widelia Andani Zekia Daroja (2222105218)
  - Sisca Cahyani (2222105250)
  - Arif Rahman (2222105006)
Kelas 2Ti04, Jurusan Teknik Informatika, Fakultas Teknik
UNIVERSITAS CENDEKIA ABDITAMA

Web-App-Zakat adalah sebuah aplikasi web yang dirancang oleh Saya (Ryu) dan teman-teman sekelompok saya, sebagai tugas untuk Ujian Tengah Semester 4 (UTS). Web Aplikasi sederhana ini digunakan untuk membantu pengelolaan data donatur, penerima zakat, dan transaksi.

Fungsi-fungsi Web App ini:

1. Pencatatan Data Donatur: Pengguna dapat mencatat informasi lengkap tentang para donatur, termasuk nama, alamat, jenis zakat yang diberikan, jumlah donasi, dan tanggal donasi.

2. Pencatatan Data Penerima Zakat: Mencatat informasi penerima zakat, seperti nama, alamat, kategori penerima, dan kebutuhan yang dimiliki.

3. Pencatatan Transaksi: Pengguna dapat mencatat transaksi yang terjadi, baik itu penerimaan zakat dari donatur maupun distribusi zakat kepada penerima yang membutuhkan.

Web-App-Zakat dirancang dengan antarmuka yang ramah pengguna dan fungsionalitas yang intuitif, sehingga memudahkan pengguna dalam mengakses dan menggunakan fitur-fitur yang disediakan. Dengan demikian, aplikasi ini dapat menjadi alat yang efektif dalam memfasilitasi pengelolaan dana zakat dengan lebih efisien dan terstruktur.
